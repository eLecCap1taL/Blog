# Summary

Date : 2024-09-22 22:41:34

Directory d:\\Program Files (x86)\\Steam\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM

Total : 216 files,  7006255 codes, 688 comments, 1168 blanks, all 7008111 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSGO cfg | 199 | 7,003,708 | 384 | 766 | 7,004,858 |
| PowerShell | 7 | 2,027 | 274 | 321 | 2,622 |
| C++ | 4 | 193 | 6 | 6 | 205 |
| Python | 1 | 191 | 14 | 35 | 240 |
| Batch | 4 | 115 | 10 | 21 | 146 |
| Markdown | 1 | 21 | 0 | 19 | 40 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 216 | 7,006,255 | 688 | 1,168 | 7,008,111 |
| . (Files) | 9 | 238 | 243 | 115 | 596 |
| Addon | 84 | 4,602,637 | 209 | 566 | 4,603,412 |
| Addon (Files) | 10 | 296 | 92 | 82 | 470 |
| Addon\\AutoAttack | 1 | 20 | 0 | 4 | 24 |
| Addon\\C4Utilities | 7 | 86 | 3 | 24 | 113 |
| Addon\\C4Utilities (Files) | 3 | 82 | 3 | 23 | 108 |
| Addon\\C4Utilities\\playerchatwheel | 4 | 4 | 0 | 1 | 5 |
| Addon\\IMStop | 11 | 1,103 | 59 | 240 | 1,402 |
| Addon\\JMove | 55 | 4,601,132 | 55 | 216 | 4,601,403 |
| Addon\\JMove (Files) | 2 | 240 | 28 | 62 | 330 |
| Addon\\JMove\\AutoStop | 4 | 181 | 22 | 46 | 249 |
| Addon\\JMove\\FastShift | 3 | 99 | 2 | 18 | 119 |
| Addon\\JMove\\Gyroscope | 3 | 43 | 1 | 4 | 48 |
| Addon\\JMove\\Ticker | 43 | 4,600,569 | 2 | 86 | 4,600,657 |
| CustomGrenade | 3 | 17 | 0 | 3 | 20 |
| Grenade | 72 | 683 | 1 | 65 | 749 |
| Grenade (Files) | 5 | 141 | 1 | 21 | 163 |
| Grenade\\Ancient | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Anubis | 6 | 48 | 0 | 3 | 51 |
| Grenade\\BUGFlash | 2 | 18 | 0 | 3 | 21 |
| Grenade\\Dust2 | 17 | 125 | 0 | 11 | 136 |
| Grenade\\Dust2 (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Dust2\\AShort | 3 | 19 | 0 | 2 | 21 |
| Grenade\\Dust2\\BBomb | 4 | 21 | 0 | 2 | 23 |
| Grenade\\Dust2\\FastMid | 2 | 19 | 0 | 2 | 21 |
| Grenade\\Dust2\\OutMid | 2 | 18 | 0 | 2 | 20 |
| Grenade\\Inferno | 12 | 103 | 0 | 9 | 112 |
| Grenade\\Inferno (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Inferno\\FAZE | 4 | 38 | 0 | 4 | 42 |
| Grenade\\Inferno\\ReABomb | 2 | 17 | 0 | 2 | 19 |
| Grenade\\Mirage | 12 | 104 | 0 | 9 | 113 |
| Grenade\\Mirage (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Mirage\\Other | 2 | 17 | 0 | 2 | 19 |
| Grenade\\Mirage\\Tramp | 2 | 18 | 0 | 2 | 20 |
| Grenade\\Mirage\\VIP | 2 | 21 | 0 | 2 | 23 |
| Grenade\\Nuke | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Vertigo | 6 | 48 | 0 | 3 | 51 |
| Radio | 8 | 139 | 21 | 26 | 186 |
| Resets | 3 | 10 | 0 | 3 | 13 |
| Settings | 7 | 83 | 5 | 18 | 106 |
| Ticker | 22 | 2,400,306 | 2 | 44 | 2,400,352 |
| install | 8 | 2,142 | 207 | 328 | 2,677 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)