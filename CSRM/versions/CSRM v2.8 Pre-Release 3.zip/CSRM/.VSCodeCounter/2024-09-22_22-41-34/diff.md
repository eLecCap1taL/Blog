# Diff Summary

Date : 2024-09-22 22:41:34

Directory d:\\Program Files (x86)\\Steam\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM

Total : 331 files,  7004242 codes, 553 comments, 789 blanks, all 7005584 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSGO cfg | 311 | 7,001,823 | 253 | 409 | 7,002,485 |
| PowerShell | 7 | 2,027 | 274 | 321 | 2,622 |
| Python | 1 | 191 | 14 | 35 | 240 |
| Batch | 4 | 115 | 10 | 21 | 146 |
| C++ | 6 | 86 | 2 | 3 | 91 |
| Markdown | 2 | 0 | 0 | 0 | 0 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 216 | 7,006,255 | 688 | 1,168 | 7,008,111 |
| . (Files) | 9 | 238 | 243 | 115 | 596 |
| Addon | 84 | 4,602,637 | 209 | 566 | 4,603,412 |
| Addon (Files) | 10 | 296 | 92 | 82 | 470 |
| Addon\\AutoAttack | 1 | 20 | 0 | 4 | 24 |
| Addon\\C4Utilities | 7 | 86 | 3 | 24 | 113 |
| Addon\\C4Utilities (Files) | 3 | 82 | 3 | 23 | 108 |
| Addon\\C4Utilities\\playerchatwheel | 4 | 4 | 0 | 1 | 5 |
| Addon\\IMStop | 11 | 1,103 | 59 | 240 | 1,402 |
| Addon\\JMove | 55 | 4,601,132 | 55 | 216 | 4,601,403 |
| Addon\\JMove (Files) | 2 | 240 | 28 | 62 | 330 |
| Addon\\JMove\\AutoStop | 4 | 181 | 22 | 46 | 249 |
| Addon\\JMove\\FastShift | 3 | 99 | 2 | 18 | 119 |
| Addon\\JMove\\Gyroscope | 3 | 43 | 1 | 4 | 48 |
| Addon\\JMove\\Ticker | 43 | 4,600,569 | 2 | 86 | 4,600,657 |
| CustomGrenade | 3 | 17 | 0 | 3 | 20 |
| Grenade | 72 | 683 | 1 | 65 | 749 |
| Grenade (Files) | 5 | 141 | 1 | 21 | 163 |
| Grenade\\Ancient | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Anubis | 6 | 48 | 0 | 3 | 51 |
| Grenade\\BUGFlash | 2 | 18 | 0 | 3 | 21 |
| Grenade\\Dust2 | 17 | 125 | 0 | 11 | 136 |
| Grenade\\Dust2 (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Dust2\\AShort | 3 | 19 | 0 | 2 | 21 |
| Grenade\\Dust2\\BBomb | 4 | 21 | 0 | 2 | 23 |
| Grenade\\Dust2\\FastMid | 2 | 19 | 0 | 2 | 21 |
| Grenade\\Dust2\\OutMid | 2 | 18 | 0 | 2 | 20 |
| Grenade\\Inferno | 12 | 103 | 0 | 9 | 112 |
| Grenade\\Inferno (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Inferno\\FAZE | 4 | 38 | 0 | 4 | 42 |
| Grenade\\Inferno\\ReABomb | 2 | 17 | 0 | 2 | 19 |
| Grenade\\Mirage | 12 | 104 | 0 | 9 | 113 |
| Grenade\\Mirage (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Mirage\\Other | 2 | 17 | 0 | 2 | 19 |
| Grenade\\Mirage\\Tramp | 2 | 18 | 0 | 2 | 20 |
| Grenade\\Mirage\\VIP | 2 | 21 | 0 | 2 | 23 |
| Grenade\\Nuke | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Vertigo | 6 | 48 | 0 | 3 | 51 |
| Radio | 8 | 139 | 21 | 26 | 186 |
| Resets | 3 | 10 | 0 | 3 | 13 |
| Settings | 7 | 83 | 5 | 18 | 106 |
| Ticker | 22 | 2,400,306 | 2 | 44 | 2,400,352 |
| f:\\ | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM | 115 | -2,013 | -135 | -379 | -2,527 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM (Files) | 4 | -150 | -128 | -65 | -343 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Addon | 23 | -1,061 | -3 | -225 | -1,289 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Addon (Files) | 6 | -58 | 0 | -26 | -84 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Addon\\FastAttack | 3 | -112 | -3 | -5 | -120 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Addon\\FastShift | 5 | -96 | 0 | -22 | -118 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Addon\\IMStop | 9 | -795 | 0 | -172 | -967 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\CustomGrenade | 3 | -18 | 0 | -2 | -20 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade | 70 | -626 | -4 | -59 | -689 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade (Files) | 5 | -102 | -4 | -18 | -124 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Ancient | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Anubis | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Dust2 | 17 | -125 | 0 | -11 | -136 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Dust2 (Files) | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Dust2\\AShort | 3 | -19 | 0 | -2 | -21 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Dust2\\BBomb | 4 | -21 | 0 | -2 | -23 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Dust2\\FastMid | 2 | -19 | 0 | -2 | -21 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Dust2\\OutMid | 2 | -18 | 0 | -2 | -20 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Inferno | 12 | -103 | 0 | -9 | -112 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Inferno (Files) | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Inferno\\FAZE | 4 | -38 | 0 | -4 | -42 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Inferno\\ReABomb | 2 | -17 | 0 | -2 | -19 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Mirage | 12 | -104 | 0 | -9 | -113 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Mirage (Files) | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Mirage\\Other | 2 | -17 | 0 | -2 | -19 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Mirage\\Tramp | 2 | -18 | 0 | -2 | -20 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Mirage\\VIP | 2 | -21 | 0 | -2 | -23 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Nuke | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Grenade\\Vertigo | 6 | -48 | 0 | -3 | -51 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Radio | 5 | -73 | 0 | -12 | -85 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Resets | 3 | -10 | 0 | -3 | -13 |
| f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM\\Settings | 7 | -75 | 0 | -13 | -88 |
| install | 8 | 2,142 | 207 | 328 | 2,677 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)