# Summary

Date : 2024-08-16 18:24:04

Directory f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM

Total : 115 files,  2013 codes, 135 comments, 379 blanks, all 2527 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSGO cfg | 112 | 1,885 | 131 | 357 | 2,373 |
| C++ | 2 | 107 | 4 | 3 | 114 |
| Markdown | 1 | 21 | 0 | 19 | 40 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 115 | 2,013 | 135 | 379 | 2,527 |
| . (Files) | 4 | 150 | 128 | 65 | 343 |
| Addon | 23 | 1,061 | 3 | 225 | 1,289 |
| Addon (Files) | 6 | 58 | 0 | 26 | 84 |
| Addon\\FastAttack | 3 | 112 | 3 | 5 | 120 |
| Addon\\FastShift | 5 | 96 | 0 | 22 | 118 |
| Addon\\IMStop | 9 | 795 | 0 | 172 | 967 |
| CustomGrenade | 3 | 18 | 0 | 2 | 20 |
| Grenade | 70 | 626 | 4 | 59 | 689 |
| Grenade (Files) | 5 | 102 | 4 | 18 | 124 |
| Grenade\\Ancient | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Anubis | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Dust2 | 17 | 125 | 0 | 11 | 136 |
| Grenade\\Dust2 (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Dust2\\AShort | 3 | 19 | 0 | 2 | 21 |
| Grenade\\Dust2\\BBomb | 4 | 21 | 0 | 2 | 23 |
| Grenade\\Dust2\\FastMid | 2 | 19 | 0 | 2 | 21 |
| Grenade\\Dust2\\OutMid | 2 | 18 | 0 | 2 | 20 |
| Grenade\\Inferno | 12 | 103 | 0 | 9 | 112 |
| Grenade\\Inferno (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Inferno\\FAZE | 4 | 38 | 0 | 4 | 42 |
| Grenade\\Inferno\\ReABomb | 2 | 17 | 0 | 2 | 19 |
| Grenade\\Mirage | 12 | 104 | 0 | 9 | 113 |
| Grenade\\Mirage (Files) | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Mirage\\Other | 2 | 17 | 0 | 2 | 19 |
| Grenade\\Mirage\\Tramp | 2 | 18 | 0 | 2 | 20 |
| Grenade\\Mirage\\VIP | 2 | 21 | 0 | 2 | 23 |
| Grenade\\Nuke | 6 | 48 | 0 | 3 | 51 |
| Grenade\\Vertigo | 6 | 48 | 0 | 3 | 51 |
| Radio | 5 | 73 | 0 | 12 | 85 |
| Resets | 3 | 10 | 0 | 3 | 13 |
| Settings | 7 | 75 | 0 | 13 | 88 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)