# Details

Date : 2024-08-16 18:24:04

Directory f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM

Total : 115 files,  2013 codes, 135 comments, 379 blanks, all 2527 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Addon/AddonMain.cfg](/Addon/AddonMain.cfg) | CSGO cfg | 7 | 0 | 2 | 9 |
| [Addon/AttackDeDefuse.cfg](/Addon/AttackDeDefuse.cfg) | CSGO cfg | 4 | 0 | 1 | 5 |
| [Addon/DuckJump.cfg](/Addon/DuckJump.cfg) | CSGO cfg | 4 | 0 | 3 | 7 |
| [Addon/FastAttack/GenLis.cpp](/Addon/FastAttack/GenLis.cpp) | C++ | 36 | 3 | 0 | 39 |
| [Addon/FastAttack/MouseXListener.cfg](/Addon/FastAttack/MouseXListener.cfg) | CSGO cfg | 12 | 0 | 4 | 16 |
| [Addon/FastAttack/Temp.cfg](/Addon/FastAttack/Temp.cfg) | CSGO cfg | 64 | 0 | 1 | 65 |
| [Addon/FastShift/FastShift.cfg](/Addon/FastShift/FastShift.cfg) | CSGO cfg | 11 | 0 | 1 | 12 |
| [Addon/FastShift/FastShiftController.cfg](/Addon/FastShift/FastShiftController.cfg) | CSGO cfg | 54 | 0 | 19 | 73 |
| [Addon/FastShift/MajorGunSwitchController.cfg](/Addon/FastShift/MajorGunSwitchController.cfg) | CSGO cfg | 15 | 0 | 0 | 15 |
| [Addon/FastShift/RadioInfo1CMD.cfg](/Addon/FastShift/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Addon/FastShift/RadioInfo1Text.cfg](/Addon/FastShift/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Addon/IMStop/IMStopDB.cfg](/Addon/IMStop/IMStopDB.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopFull.cfg](/Addon/IMStop/IMStopFull.cfg) | CSGO cfg | 111 | 0 | 24 | 135 |
| [Addon/IMStop/IMStopFull1.cfg](/Addon/IMStop/IMStopFull1.cfg) | CSGO cfg | 118 | 0 | 26 | 144 |
| [Addon/IMStop/IMStopMain.cfg](/Addon/IMStop/IMStopMain.cfg) | CSGO cfg | 56 | 0 | 14 | 70 |
| [Addon/IMStop/IMStopNone.cfg](/Addon/IMStop/IMStopNone.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopOld.cfg](/Addon/IMStop/IMStopOld.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopOnlyWS.cfg](/Addon/IMStop/IMStopOnlyWS.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopSnapTap.cfg](/Addon/IMStop/IMStopSnapTap.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopWC.cfg](/Addon/IMStop/IMStopWC.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/RegEdit.cfg](/Addon/RegEdit.cfg) | CSGO cfg | 26 | 0 | 15 | 41 |
| [Addon/WheelJump.cfg](/Addon/WheelJump.cfg) | CSGO cfg | 15 | 0 | 5 | 20 |
| [Addon/WheelJumpDesubtick.cfg](/Addon/WheelJumpDesubtick.cfg) | CSGO cfg | 2 | 0 | 0 | 2 |
| [CustomGrenade/CustomGrenadeRegedit.cfg](/CustomGrenade/CustomGrenadeRegedit.cfg) | CSGO cfg | 2 | 0 | 0 | 2 |
| [CustomGrenade/RadioInfo1CMD.cfg](/CustomGrenade/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [CustomGrenade/RadioInfo1Text.cfg](/CustomGrenade/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Ancient/RadioCate1CMD.cfg](/Grenade/Ancient/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Ancient/RadioCate1Text.cfg](/Grenade/Ancient/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Ancient/RadioCate2CMD.cfg](/Grenade/Ancient/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Ancient/RadioCate2Text.cfg](/Grenade/Ancient/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Ancient/RadioCate3CMD.cfg](/Grenade/Ancient/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Ancient/RadioCate3Text.cfg](/Grenade/Ancient/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Anubis/RadioCate1CMD.cfg](/Grenade/Anubis/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Anubis/RadioCate1Text.cfg](/Grenade/Anubis/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Anubis/RadioCate2CMD.cfg](/Grenade/Anubis/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Anubis/RadioCate2Text.cfg](/Grenade/Anubis/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Anubis/RadioCate3CMD.cfg](/Grenade/Anubis/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Anubis/RadioCate3Text.cfg](/Grenade/Anubis/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/AShort/RadioInfo1CMD.cfg](/Grenade/Dust2/AShort/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 1 | 11 |
| [Grenade/Dust2/AShort/RadioInfo1Text.cfg](/Grenade/Dust2/AShort/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/AShort/SetAISW1.cfg](/Grenade/Dust2/AShort/SetAISW1.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Grenade/Dust2/BBomb/RadioInfo1CMD.cfg](/Grenade/Dust2/BBomb/RadioInfo1CMD.cfg) | CSGO cfg | 11 | 0 | 1 | 12 |
| [Grenade/Dust2/BBomb/RadioInfo1Text.cfg](/Grenade/Dust2/BBomb/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/BBomb/SetAISW1.cfg](/Grenade/Dust2/BBomb/SetAISW1.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Grenade/Dust2/BBomb/SetAISW2.cfg](/Grenade/Dust2/BBomb/SetAISW2.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Grenade/Dust2/FastMid/RadioInfo1CMD.cfg](/Grenade/Dust2/FastMid/RadioInfo1CMD.cfg) | CSGO cfg | 11 | 0 | 1 | 12 |
| [Grenade/Dust2/FastMid/RadioInfo1Text.cfg](/Grenade/Dust2/FastMid/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/OutMid/RadioInfo1CMD.cfg](/Grenade/Dust2/OutMid/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 1 | 11 |
| [Grenade/Dust2/OutMid/RadioInfo1Text.cfg](/Grenade/Dust2/OutMid/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/RadioCate1CMD.cfg](/Grenade/Dust2/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Dust2/RadioCate1Text.cfg](/Grenade/Dust2/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/RadioCate2CMD.cfg](/Grenade/Dust2/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Dust2/RadioCate2Text.cfg](/Grenade/Dust2/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/RadioCate3CMD.cfg](/Grenade/Dust2/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Dust2/RadioCate3Text.cfg](/Grenade/Dust2/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/GrenadeMain.cfg](/Grenade/GrenadeMain.cfg) | CSGO cfg | 33 | 3 | 10 | 46 |
| [Grenade/GrenadeRegedit.cfg](/Grenade/GrenadeRegedit.cfg) | CSGO cfg | 26 | 0 | 3 | 29 |
| [Grenade/GrenadeRegedit_Relative.cfg](/Grenade/GrenadeRegedit_Relative.cfg) | CSGO cfg | 26 | 1 | 4 | 31 |
| [Grenade/Inferno/FAZE/RadioInfo1CMD.cfg](/Grenade/Inferno/FAZE/RadioInfo1CMD.cfg) | CSGO cfg | 13 | 0 | 1 | 14 |
| [Grenade/Inferno/FAZE/RadioInfo1Text.cfg](/Grenade/Inferno/FAZE/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/FAZE/RadioInfo2CMD.cfg](/Grenade/Inferno/FAZE/RadioInfo2CMD.cfg) | CSGO cfg | 9 | 0 | 1 | 10 |
| [Grenade/Inferno/FAZE/RadioInfo2Text.cfg](/Grenade/Inferno/FAZE/RadioInfo2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/RadioCate1CMD.cfg](/Grenade/Inferno/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Inferno/RadioCate1Text.cfg](/Grenade/Inferno/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/RadioCate2CMD.cfg](/Grenade/Inferno/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Inferno/RadioCate2Text.cfg](/Grenade/Inferno/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/RadioCate3CMD.cfg](/Grenade/Inferno/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Inferno/RadioCate3Text.cfg](/Grenade/Inferno/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/ReABomb/RadioInfo1CMD.cfg](/Grenade/Inferno/ReABomb/RadioInfo1CMD.cfg) | CSGO cfg | 9 | 0 | 1 | 10 |
| [Grenade/Inferno/ReABomb/RadioInfo1Text.cfg](/Grenade/Inferno/ReABomb/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/Other/RadioInfo1CMD.cfg](/Grenade/Mirage/Other/RadioInfo1CMD.cfg) | CSGO cfg | 9 | 0 | 1 | 10 |
| [Grenade/Mirage/Other/RadioInfo1Text.cfg](/Grenade/Mirage/Other/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/RadioCate1CMD.cfg](/Grenade/Mirage/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Mirage/RadioCate1Text.cfg](/Grenade/Mirage/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/RadioCate2CMD.cfg](/Grenade/Mirage/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Mirage/RadioCate2Text.cfg](/Grenade/Mirage/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/RadioCate3CMD.cfg](/Grenade/Mirage/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Mirage/RadioCate3Text.cfg](/Grenade/Mirage/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/Tramp/RadioInfo1CMD.cfg](/Grenade/Mirage/Tramp/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 1 | 11 |
| [Grenade/Mirage/Tramp/RadioInfo1Text.cfg](/Grenade/Mirage/Tramp/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/VIP/RadioInfo1CMD.cfg](/Grenade/Mirage/VIP/RadioInfo1CMD.cfg) | CSGO cfg | 13 | 0 | 1 | 14 |
| [Grenade/Mirage/VIP/RadioInfo1Text.cfg](/Grenade/Mirage/VIP/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Nuke/RadioCate1CMD.cfg](/Grenade/Nuke/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Nuke/RadioCate1Text.cfg](/Grenade/Nuke/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Nuke/RadioCate2CMD.cfg](/Grenade/Nuke/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Nuke/RadioCate2Text.cfg](/Grenade/Nuke/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Nuke/RadioCate3CMD.cfg](/Grenade/Nuke/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Nuke/RadioCate3Text.cfg](/Grenade/Nuke/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/RadioMapChooseCMD.cfg](/Grenade/RadioMapChooseCMD.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Grenade/RadioMapChooseText.cfg](/Grenade/RadioMapChooseText.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Vertigo/RadioCate1CMD.cfg](/Grenade/Vertigo/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Vertigo/RadioCate1Text.cfg](/Grenade/Vertigo/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Vertigo/RadioCate2CMD.cfg](/Grenade/Vertigo/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Vertigo/RadioCate2Text.cfg](/Grenade/Vertigo/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Vertigo/RadioCate3CMD.cfg](/Grenade/Vertigo/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Vertigo/RadioCate3Text.cfg](/Grenade/Vertigo/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Main.cfg](/Main.cfg) | CSGO cfg | 15 | 0 | 6 | 21 |
| [Preference.cfg](/Preference.cfg) | CSGO cfg | 43 | 127 | 37 | 207 |
| [README.md](/README.md) | Markdown | 21 | 0 | 19 | 40 |
| [Radio/CFGMain1CMD.cfg](/Radio/CFGMain1CMD.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Radio/CFGMain1Text.cfg](/Radio/CFGMain1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Radio/MajorOutputController.cfg](/Radio/MajorOutputController.cfg) | CSGO cfg | 9 | 0 | 5 | 14 |
| [Radio/RadioDefault.cfg](/Radio/RadioDefault.cfg) | CSGO cfg | 25 | 0 | 0 | 25 |
| [Radio/RadioMain.cfg](/Radio/RadioMain.cfg) | CSGO cfg | 22 | 0 | 6 | 28 |
| [Resets/AddonReset.cfg](/Resets/AddonReset.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Resets/GrenadeReset.cfg](/Resets/GrenadeReset.cfg) | CSGO cfg | 6 | 0 | 1 | 7 |
| [Resets/RadioReset.cfg](/Resets/RadioReset.cfg) | CSGO cfg | 3 | 0 | 2 | 5 |
| [Settings/OutputSettingsList.cfg](/Settings/OutputSettingsList.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Settings/RadioInfo1CMD.cfg](/Settings/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Settings/RadioInfo1Text.cfg](/Settings/RadioInfo1Text.cfg) | CSGO cfg | 14 | 0 | 4 | 18 |
| [Settings/RadioInfo2CMD.cfg](/Settings/RadioInfo2CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Settings/RadioInfo2Text.cfg](/Settings/RadioInfo2Text.cfg) | CSGO cfg | 20 | 0 | 5 | 25 |
| [Settings/RadioInfo3CMD.cfg](/Settings/RadioInfo3CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Settings/RadioInfo3Text.cfg](/Settings/RadioInfo3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [一键添加自定义道具(半成品).cpp](/%E4%B8%80%E9%94%AE%E6%B7%BB%E5%8A%A0%E8%87%AA%E5%AE%9A%E4%B9%89%E9%81%93%E5%85%B7(%E5%8D%8A%E6%88%90%E5%93%81).cpp) | C++ | 71 | 1 | 3 | 75 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)