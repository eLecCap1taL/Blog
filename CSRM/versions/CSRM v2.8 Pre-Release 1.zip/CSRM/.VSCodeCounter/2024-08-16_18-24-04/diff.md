# Diff Summary

Date : 2024-08-16 18:24:04

Directory f:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM

Total : 2 files,  0 codes, 0 comments, 0 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSGO cfg | 2 | 0 | 0 | 0 | 0 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 2 | 0 | 0 | 0 | 0 |
| . (Files) | 1 | 2 | 0 | 2 | 4 |
| Addon | 1 | -2 | 0 | -2 | -4 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)