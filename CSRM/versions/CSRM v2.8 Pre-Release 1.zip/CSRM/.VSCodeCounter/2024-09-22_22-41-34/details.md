# Details

Date : 2024-09-22 22:41:34

Directory d:\\Program Files (x86)\\Steam\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo\\cfg\\CSRM

Total : 216 files,  7006255 codes, 688 comments, 1168 blanks, all 7008111 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Addon/AddonMain.cfg](/Addon/AddonMain.cfg) | CSGO cfg | 11 | 0 | 1 | 12 |
| [Addon/AttackDeDefuse.cfg](/Addon/AttackDeDefuse.cfg) | CSGO cfg | 5 | 0 | 2 | 7 |
| [Addon/AutoAttack/AutoAttack.cfg](/Addon/AutoAttack/AutoAttack.cfg) | CSGO cfg | 20 | 0 | 4 | 24 |
| [Addon/C4Utilities/C4Utilities.cfg](/Addon/C4Utilities/C4Utilities.cfg) | CSGO cfg | 62 | 3 | 17 | 82 |
| [Addon/C4Utilities/RadioInfo1CMD.cfg](/Addon/C4Utilities/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Addon/C4Utilities/RadioInfo1Text.cfg](/Addon/C4Utilities/RadioInfo1Text.cfg) | CSGO cfg | 12 | 0 | 5 | 17 |
| [Addon/C4Utilities/playerchatwheel/C4InAir.cfg](/Addon/C4Utilities/playerchatwheel/C4InAir.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Addon/C4Utilities/playerchatwheel/C4OnLand.cfg](/Addon/C4Utilities/playerchatwheel/C4OnLand.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Addon/C4Utilities/playerchatwheel/C4OnMan.cfg](/Addon/C4Utilities/playerchatwheel/C4OnMan.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Addon/C4Utilities/playerchatwheel/C4Planted.cfg](/Addon/C4Utilities/playerchatwheel/C4Planted.cfg) | CSGO cfg | 1 | 0 | 1 | 2 |
| [Addon/CrossHairWork.cfg](/Addon/CrossHairWork.cfg) | CSGO cfg | 35 | 10 | 16 | 61 |
| [Addon/CrossHairWork_Changer.cfg](/Addon/CrossHairWork_Changer.cfg) | CSGO cfg | 35 | 0 | 2 | 37 |
| [Addon/DuckJump.cfg](/Addon/DuckJump.cfg) | CSGO cfg | 4 | 0 | 3 | 7 |
| [Addon/GetCrossHair.ps1](/Addon/GetCrossHair.ps1) | PowerShell | 149 | 82 | 31 | 262 |
| [Addon/IMStop/8DirectionAutoStop.cfg](/Addon/IMStop/8DirectionAutoStop.cfg) | CSGO cfg | 205 | 26 | 48 | 279 |
| [Addon/IMStop/IMStopDB.cfg](/Addon/IMStop/IMStopDB.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopFull.cfg](/Addon/IMStop/IMStopFull.cfg) | CSGO cfg | 111 | 0 | 24 | 135 |
| [Addon/IMStop/IMStopMain.cfg](/Addon/IMStop/IMStopMain.cfg) | CSGO cfg | 21 | 4 | 6 | 31 |
| [Addon/IMStop/IMStopNone.cfg](/Addon/IMStop/IMStopNone.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopOld.cfg](/Addon/IMStop/IMStopOld.cfg) | CSGO cfg | 101 | 2 | 23 | 126 |
| [Addon/IMStop/IMStopOnlyWS.cfg](/Addon/IMStop/IMStopOnlyWS.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopSnapTap.cfg](/Addon/IMStop/IMStopSnapTap.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/IMStopWC.cfg](/Addon/IMStop/IMStopWC.cfg) | CSGO cfg | 85 | 0 | 18 | 103 |
| [Addon/IMStop/jiami.cfg](/Addon/IMStop/jiami.cfg) | CSGO cfg | 205 | 26 | 48 | 279 |
| [Addon/IMStop/加密.cpp](/Addon/IMStop/%E5%8A%A0%E5%AF%86.cpp) | C++ | 35 | 1 | 1 | 37 |
| [Addon/JMove/AutoStop/AutoStopFull.cfg](/Addon/JMove/AutoStop/AutoStopFull.cfg) | CSGO cfg | 83 | 1 | 16 | 100 |
| [Addon/JMove/AutoStop/AutoStopKB.cfg](/Addon/JMove/AutoStop/AutoStopKB.cfg) | CSGO cfg | 47 | 1 | 14 | 62 |
| [Addon/JMove/AutoStop/AutoStopNone.cfg](/Addon/JMove/AutoStop/AutoStopNone.cfg) | CSGO cfg | 47 | 1 | 13 | 61 |
| [Addon/JMove/AutoStop/AutoStopSwitcher.cfg](/Addon/JMove/AutoStop/AutoStopSwitcher.cfg) | CSGO cfg | 4 | 19 | 3 | 26 |
| [Addon/JMove/Eventer.cfg](/Addon/JMove/Eventer.cfg) | CSGO cfg | 81 | 0 | 14 | 95 |
| [Addon/JMove/FastShift/FastShift.cfg](/Addon/JMove/FastShift/FastShift.cfg) | CSGO cfg | 83 | 2 | 16 | 101 |
| [Addon/JMove/FastShift/RadioInfo1CMD.cfg](/Addon/JMove/FastShift/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Addon/JMove/FastShift/RadioInfo1Text.cfg](/Addon/JMove/FastShift/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Addon/JMove/Gyroscope/Gyroscope.cfg](/Addon/JMove/Gyroscope/Gyroscope.cfg) | CSGO cfg | 26 | 1 | 3 | 30 |
| [Addon/JMove/Gyroscope/RadioInfo1CMD.cfg](/Addon/JMove/Gyroscope/RadioInfo1CMD.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Addon/JMove/Gyroscope/RadioInfo1Text.cfg](/Addon/JMove/Gyroscope/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Addon/JMove/JMove.cfg](/Addon/JMove/JMove.cfg) | CSGO cfg | 159 | 28 | 48 | 235 |
| [Addon/JMove/Ticker/JMoveJumpTicker.cfg](/Addon/JMove/Ticker/JMoveJumpTicker.cfg) | CSGO cfg | 47 | 0 | 23 | 70 |
| [Addon/JMove/Ticker/JMoveJumpTicker1.cfg](/Addon/JMove/Ticker/JMoveJumpTicker1.cfg) | CSGO cfg | 110,001 | 0 | 1 | 110,002 |
| [Addon/JMove/Ticker/JMoveJumpTicker10.cfg](/Addon/JMove/Ticker/JMoveJumpTicker10.cfg) | CSGO cfg | 110,010 | 0 | 1 | 110,011 |
| [Addon/JMove/Ticker/JMoveJumpTicker11.cfg](/Addon/JMove/Ticker/JMoveJumpTicker11.cfg) | CSGO cfg | 110,011 | 0 | 1 | 110,012 |
| [Addon/JMove/Ticker/JMoveJumpTicker12.cfg](/Addon/JMove/Ticker/JMoveJumpTicker12.cfg) | CSGO cfg | 110,012 | 0 | 1 | 110,013 |
| [Addon/JMove/Ticker/JMoveJumpTicker13.cfg](/Addon/JMove/Ticker/JMoveJumpTicker13.cfg) | CSGO cfg | 110,013 | 0 | 1 | 110,014 |
| [Addon/JMove/Ticker/JMoveJumpTicker14.cfg](/Addon/JMove/Ticker/JMoveJumpTicker14.cfg) | CSGO cfg | 110,014 | 0 | 1 | 110,015 |
| [Addon/JMove/Ticker/JMoveJumpTicker15.cfg](/Addon/JMove/Ticker/JMoveJumpTicker15.cfg) | CSGO cfg | 110,015 | 0 | 1 | 110,016 |
| [Addon/JMove/Ticker/JMoveJumpTicker16.cfg](/Addon/JMove/Ticker/JMoveJumpTicker16.cfg) | CSGO cfg | 110,016 | 0 | 1 | 110,017 |
| [Addon/JMove/Ticker/JMoveJumpTicker17.cfg](/Addon/JMove/Ticker/JMoveJumpTicker17.cfg) | CSGO cfg | 110,017 | 0 | 1 | 110,018 |
| [Addon/JMove/Ticker/JMoveJumpTicker18.cfg](/Addon/JMove/Ticker/JMoveJumpTicker18.cfg) | CSGO cfg | 110,018 | 0 | 1 | 110,019 |
| [Addon/JMove/Ticker/JMoveJumpTicker19.cfg](/Addon/JMove/Ticker/JMoveJumpTicker19.cfg) | CSGO cfg | 110,019 | 0 | 1 | 110,020 |
| [Addon/JMove/Ticker/JMoveJumpTicker2.cfg](/Addon/JMove/Ticker/JMoveJumpTicker2.cfg) | CSGO cfg | 110,002 | 0 | 1 | 110,003 |
| [Addon/JMove/Ticker/JMoveJumpTicker20.cfg](/Addon/JMove/Ticker/JMoveJumpTicker20.cfg) | CSGO cfg | 110,020 | 0 | 1 | 110,021 |
| [Addon/JMove/Ticker/JMoveJumpTicker3.cfg](/Addon/JMove/Ticker/JMoveJumpTicker3.cfg) | CSGO cfg | 110,003 | 0 | 1 | 110,004 |
| [Addon/JMove/Ticker/JMoveJumpTicker4.cfg](/Addon/JMove/Ticker/JMoveJumpTicker4.cfg) | CSGO cfg | 110,004 | 0 | 1 | 110,005 |
| [Addon/JMove/Ticker/JMoveJumpTicker5.cfg](/Addon/JMove/Ticker/JMoveJumpTicker5.cfg) | CSGO cfg | 110,005 | 0 | 1 | 110,006 |
| [Addon/JMove/Ticker/JMoveJumpTicker6.cfg](/Addon/JMove/Ticker/JMoveJumpTicker6.cfg) | CSGO cfg | 110,006 | 0 | 1 | 110,007 |
| [Addon/JMove/Ticker/JMoveJumpTicker7.cfg](/Addon/JMove/Ticker/JMoveJumpTicker7.cfg) | CSGO cfg | 110,007 | 0 | 1 | 110,008 |
| [Addon/JMove/Ticker/JMoveJumpTicker8.cfg](/Addon/JMove/Ticker/JMoveJumpTicker8.cfg) | CSGO cfg | 110,008 | 0 | 1 | 110,009 |
| [Addon/JMove/Ticker/JMoveJumpTicker9.cfg](/Addon/JMove/Ticker/JMoveJumpTicker9.cfg) | CSGO cfg | 110,009 | 0 | 1 | 110,010 |
| [Addon/JMove/Ticker/JMoveTicker.cfg](/Addon/JMove/Ticker/JMoveTicker.cfg) | CSGO cfg | 58 | 0 | 23 | 81 |
| [Addon/JMove/Ticker/JMoveTicker1.cfg](/Addon/JMove/Ticker/JMoveTicker1.cfg) | CSGO cfg | 120,001 | 0 | 1 | 120,002 |
| [Addon/JMove/Ticker/JMoveTicker10.cfg](/Addon/JMove/Ticker/JMoveTicker10.cfg) | CSGO cfg | 120,010 | 0 | 1 | 120,011 |
| [Addon/JMove/Ticker/JMoveTicker11.cfg](/Addon/JMove/Ticker/JMoveTicker11.cfg) | CSGO cfg | 120,011 | 0 | 1 | 120,012 |
| [Addon/JMove/Ticker/JMoveTicker12.cfg](/Addon/JMove/Ticker/JMoveTicker12.cfg) | CSGO cfg | 120,012 | 0 | 1 | 120,013 |
| [Addon/JMove/Ticker/JMoveTicker13.cfg](/Addon/JMove/Ticker/JMoveTicker13.cfg) | CSGO cfg | 120,013 | 0 | 1 | 120,014 |
| [Addon/JMove/Ticker/JMoveTicker14.cfg](/Addon/JMove/Ticker/JMoveTicker14.cfg) | CSGO cfg | 120,014 | 0 | 1 | 120,015 |
| [Addon/JMove/Ticker/JMoveTicker15.cfg](/Addon/JMove/Ticker/JMoveTicker15.cfg) | CSGO cfg | 120,015 | 0 | 1 | 120,016 |
| [Addon/JMove/Ticker/JMoveTicker16.cfg](/Addon/JMove/Ticker/JMoveTicker16.cfg) | CSGO cfg | 120,016 | 0 | 1 | 120,017 |
| [Addon/JMove/Ticker/JMoveTicker17.cfg](/Addon/JMove/Ticker/JMoveTicker17.cfg) | CSGO cfg | 120,017 | 0 | 1 | 120,018 |
| [Addon/JMove/Ticker/JMoveTicker18.cfg](/Addon/JMove/Ticker/JMoveTicker18.cfg) | CSGO cfg | 120,018 | 0 | 1 | 120,019 |
| [Addon/JMove/Ticker/JMoveTicker19.cfg](/Addon/JMove/Ticker/JMoveTicker19.cfg) | CSGO cfg | 120,019 | 0 | 1 | 120,020 |
| [Addon/JMove/Ticker/JMoveTicker2.cfg](/Addon/JMove/Ticker/JMoveTicker2.cfg) | CSGO cfg | 120,002 | 0 | 1 | 120,003 |
| [Addon/JMove/Ticker/JMoveTicker20.cfg](/Addon/JMove/Ticker/JMoveTicker20.cfg) | CSGO cfg | 120,021 | 0 | 0 | 120,021 |
| [Addon/JMove/Ticker/JMoveTicker3.cfg](/Addon/JMove/Ticker/JMoveTicker3.cfg) | CSGO cfg | 120,003 | 0 | 1 | 120,004 |
| [Addon/JMove/Ticker/JMoveTicker4.cfg](/Addon/JMove/Ticker/JMoveTicker4.cfg) | CSGO cfg | 120,004 | 0 | 1 | 120,005 |
| [Addon/JMove/Ticker/JMoveTicker5.cfg](/Addon/JMove/Ticker/JMoveTicker5.cfg) | CSGO cfg | 120,005 | 0 | 1 | 120,006 |
| [Addon/JMove/Ticker/JMoveTicker6.cfg](/Addon/JMove/Ticker/JMoveTicker6.cfg) | CSGO cfg | 120,006 | 0 | 1 | 120,007 |
| [Addon/JMove/Ticker/JMoveTicker7.cfg](/Addon/JMove/Ticker/JMoveTicker7.cfg) | CSGO cfg | 120,007 | 0 | 1 | 120,008 |
| [Addon/JMove/Ticker/JMoveTicker8.cfg](/Addon/JMove/Ticker/JMoveTicker8.cfg) | CSGO cfg | 120,008 | 0 | 1 | 120,009 |
| [Addon/JMove/Ticker/JMoveTicker9.cfg](/Addon/JMove/Ticker/JMoveTicker9.cfg) | CSGO cfg | 120,009 | 0 | 1 | 120,010 |
| [Addon/JMove/Ticker/JMoveTickerGen.cpp](/Addon/JMove/Ticker/JMoveTickerGen.cpp) | C++ | 43 | 2 | 1 | 46 |
| [Addon/PlayerCrossHair.cfg](/Addon/PlayerCrossHair.cfg) | CSGO cfg | 4 | 0 | 2 | 6 |
| [Addon/RegEdit.cfg](/Addon/RegEdit.cfg) | CSGO cfg | 33 | 0 | 18 | 51 |
| [Addon/WheelJump.cfg](/Addon/WheelJump.cfg) | CSGO cfg | 18 | 0 | 6 | 24 |
| [Addon/WheelJumpDesubtick.cfg](/Addon/WheelJumpDesubtick.cfg) | CSGO cfg | 2 | 0 | 1 | 3 |
| [CustomGrenade/CustomGrenadeRegedit.cfg](/CustomGrenade/CustomGrenadeRegedit.cfg) | CSGO cfg | 1 | 0 | 1 | 2 |
| [CustomGrenade/RadioInfo1CMD.cfg](/CustomGrenade/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [CustomGrenade/RadioInfo1Text.cfg](/CustomGrenade/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Ancient/RadioCate1CMD.cfg](/Grenade/Ancient/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Ancient/RadioCate1Text.cfg](/Grenade/Ancient/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Ancient/RadioCate2CMD.cfg](/Grenade/Ancient/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Ancient/RadioCate2Text.cfg](/Grenade/Ancient/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Ancient/RadioCate3CMD.cfg](/Grenade/Ancient/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Ancient/RadioCate3Text.cfg](/Grenade/Ancient/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Anubis/RadioCate1CMD.cfg](/Grenade/Anubis/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Anubis/RadioCate1Text.cfg](/Grenade/Anubis/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Anubis/RadioCate2CMD.cfg](/Grenade/Anubis/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Anubis/RadioCate2Text.cfg](/Grenade/Anubis/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Anubis/RadioCate3CMD.cfg](/Grenade/Anubis/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Anubis/RadioCate3Text.cfg](/Grenade/Anubis/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/BUGFlash/RadioInfo1CMD.cfg](/Grenade/BUGFlash/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 2 | 12 |
| [Grenade/BUGFlash/RadioInfo1Text.cfg](/Grenade/BUGFlash/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/AShort/RadioInfo1CMD.cfg](/Grenade/Dust2/AShort/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 1 | 11 |
| [Grenade/Dust2/AShort/RadioInfo1Text.cfg](/Grenade/Dust2/AShort/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/AShort/SetAISW1.cfg](/Grenade/Dust2/AShort/SetAISW1.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Grenade/Dust2/BBomb/RadioInfo1CMD.cfg](/Grenade/Dust2/BBomb/RadioInfo1CMD.cfg) | CSGO cfg | 11 | 0 | 1 | 12 |
| [Grenade/Dust2/BBomb/RadioInfo1Text.cfg](/Grenade/Dust2/BBomb/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/BBomb/SetAISW1.cfg](/Grenade/Dust2/BBomb/SetAISW1.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Grenade/Dust2/BBomb/SetAISW2.cfg](/Grenade/Dust2/BBomb/SetAISW2.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Grenade/Dust2/FastMid/RadioInfo1CMD.cfg](/Grenade/Dust2/FastMid/RadioInfo1CMD.cfg) | CSGO cfg | 11 | 0 | 1 | 12 |
| [Grenade/Dust2/FastMid/RadioInfo1Text.cfg](/Grenade/Dust2/FastMid/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/OutMid/RadioInfo1CMD.cfg](/Grenade/Dust2/OutMid/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 1 | 11 |
| [Grenade/Dust2/OutMid/RadioInfo1Text.cfg](/Grenade/Dust2/OutMid/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/RadioCate1CMD.cfg](/Grenade/Dust2/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Dust2/RadioCate1Text.cfg](/Grenade/Dust2/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/RadioCate2CMD.cfg](/Grenade/Dust2/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Dust2/RadioCate2Text.cfg](/Grenade/Dust2/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Dust2/RadioCate3CMD.cfg](/Grenade/Dust2/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Dust2/RadioCate3Text.cfg](/Grenade/Dust2/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/GrenadeMain.cfg](/Grenade/GrenadeMain.cfg) | CSGO cfg | 67 | 0 | 13 | 80 |
| [Grenade/GrenadeRegedit.cfg](/Grenade/GrenadeRegedit.cfg) | CSGO cfg | 31 | 0 | 3 | 34 |
| [Grenade/GrenadeRegedit_Relative.cfg](/Grenade/GrenadeRegedit_Relative.cfg) | CSGO cfg | 26 | 1 | 4 | 31 |
| [Grenade/Inferno/FAZE/RadioInfo1CMD.cfg](/Grenade/Inferno/FAZE/RadioInfo1CMD.cfg) | CSGO cfg | 13 | 0 | 1 | 14 |
| [Grenade/Inferno/FAZE/RadioInfo1Text.cfg](/Grenade/Inferno/FAZE/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/FAZE/RadioInfo2CMD.cfg](/Grenade/Inferno/FAZE/RadioInfo2CMD.cfg) | CSGO cfg | 9 | 0 | 1 | 10 |
| [Grenade/Inferno/FAZE/RadioInfo2Text.cfg](/Grenade/Inferno/FAZE/RadioInfo2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/RadioCate1CMD.cfg](/Grenade/Inferno/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Inferno/RadioCate1Text.cfg](/Grenade/Inferno/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/RadioCate2CMD.cfg](/Grenade/Inferno/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Inferno/RadioCate2Text.cfg](/Grenade/Inferno/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/RadioCate3CMD.cfg](/Grenade/Inferno/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Inferno/RadioCate3Text.cfg](/Grenade/Inferno/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Inferno/ReABomb/RadioInfo1CMD.cfg](/Grenade/Inferno/ReABomb/RadioInfo1CMD.cfg) | CSGO cfg | 9 | 0 | 1 | 10 |
| [Grenade/Inferno/ReABomb/RadioInfo1Text.cfg](/Grenade/Inferno/ReABomb/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/Other/RadioInfo1CMD.cfg](/Grenade/Mirage/Other/RadioInfo1CMD.cfg) | CSGO cfg | 9 | 0 | 1 | 10 |
| [Grenade/Mirage/Other/RadioInfo1Text.cfg](/Grenade/Mirage/Other/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/RadioCate1CMD.cfg](/Grenade/Mirage/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Mirage/RadioCate1Text.cfg](/Grenade/Mirage/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/RadioCate2CMD.cfg](/Grenade/Mirage/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Mirage/RadioCate2Text.cfg](/Grenade/Mirage/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/RadioCate3CMD.cfg](/Grenade/Mirage/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Mirage/RadioCate3Text.cfg](/Grenade/Mirage/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/Tramp/RadioInfo1CMD.cfg](/Grenade/Mirage/Tramp/RadioInfo1CMD.cfg) | CSGO cfg | 10 | 0 | 1 | 11 |
| [Grenade/Mirage/Tramp/RadioInfo1Text.cfg](/Grenade/Mirage/Tramp/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Mirage/VIP/RadioInfo1CMD.cfg](/Grenade/Mirage/VIP/RadioInfo1CMD.cfg) | CSGO cfg | 13 | 0 | 1 | 14 |
| [Grenade/Mirage/VIP/RadioInfo1Text.cfg](/Grenade/Mirage/VIP/RadioInfo1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Nuke/RadioCate1CMD.cfg](/Grenade/Nuke/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Nuke/RadioCate1Text.cfg](/Grenade/Nuke/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Nuke/RadioCate2CMD.cfg](/Grenade/Nuke/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Nuke/RadioCate2Text.cfg](/Grenade/Nuke/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Nuke/RadioCate3CMD.cfg](/Grenade/Nuke/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Nuke/RadioCate3Text.cfg](/Grenade/Nuke/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/RadioMapChooseCMD.cfg](/Grenade/RadioMapChooseCMD.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Grenade/RadioMapChooseText.cfg](/Grenade/RadioMapChooseText.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Vertigo/RadioCate1CMD.cfg](/Grenade/Vertigo/RadioCate1CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Vertigo/RadioCate1Text.cfg](/Grenade/Vertigo/RadioCate1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Vertigo/RadioCate2CMD.cfg](/Grenade/Vertigo/RadioCate2CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Vertigo/RadioCate2Text.cfg](/Grenade/Vertigo/RadioCate2Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Grenade/Vertigo/RadioCate3CMD.cfg](/Grenade/Vertigo/RadioCate3CMD.cfg) | CSGO cfg | 8 | 0 | 0 | 8 |
| [Grenade/Vertigo/RadioCate3Text.cfg](/Grenade/Vertigo/RadioCate3Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Main.cfg](/Main.cfg) | CSGO cfg | 6 | 0 | 0 | 6 |
| [MainDG.cfg](/MainDG.cfg) | CSGO cfg | 20 | 4 | 8 | 32 |
| [MainDT.cfg](/MainDT.cfg) | CSGO cfg | 16 | 8 | 8 | 32 |
| [Preference.cfg](/Preference.cfg) | CSGO cfg | 60 | 221 | 59 | 340 |
| [README.md](/README.md) | Markdown | 21 | 0 | 19 | 40 |
| [Radio/CFGMain1CMD.cfg](/Radio/CFGMain1CMD.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Radio/CFGMain1Text.cfg](/Radio/CFGMain1Text.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Radio/CFGMain2CMD.cfg](/Radio/CFGMain2CMD.cfg) | CSGO cfg | 9 | 0 | 0 | 9 |
| [Radio/CFGMain2Text.cfg](/Radio/CFGMain2Text.cfg) | CSGO cfg | 10 | 0 | 3 | 13 |
| [Radio/GetCurMap.cfg](/Radio/GetCurMap.cfg) | CSGO cfg | 21 | 15 | 2 | 38 |
| [Radio/MajorOutputController.cfg](/Radio/MajorOutputController.cfg) | CSGO cfg | 17 | 0 | 8 | 25 |
| [Radio/RadioDefault.cfg](/Radio/RadioDefault.cfg) | CSGO cfg | 25 | 0 | 0 | 25 |
| [Radio/RadioMain.cfg](/Radio/RadioMain.cfg) | CSGO cfg | 40 | 6 | 12 | 58 |
| [Resets/AddonReset.cfg](/Resets/AddonReset.cfg) | CSGO cfg | 1 | 0 | 0 | 1 |
| [Resets/GrenadeReset.cfg](/Resets/GrenadeReset.cfg) | CSGO cfg | 6 | 0 | 1 | 7 |
| [Resets/RadioReset.cfg](/Resets/RadioReset.cfg) | CSGO cfg | 3 | 0 | 2 | 5 |
| [Settings/OutputSettingsList.cfg](/Settings/OutputSettingsList.cfg) | CSGO cfg | 13 | 0 | 0 | 13 |
| [Settings/RadioInfo1CMD.cfg](/Settings/RadioInfo1CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Settings/RadioInfo1Text.cfg](/Settings/RadioInfo1Text.cfg) | CSGO cfg | 14 | 0 | 4 | 18 |
| [Settings/RadioInfo2CMD.cfg](/Settings/RadioInfo2CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Settings/RadioInfo2Text.cfg](/Settings/RadioInfo2Text.cfg) | CSGO cfg | 20 | 5 | 7 | 32 |
| [Settings/RadioInfo3CMD.cfg](/Settings/RadioInfo3CMD.cfg) | CSGO cfg | 8 | 0 | 1 | 9 |
| [Settings/RadioInfo3Text.cfg](/Settings/RadioInfo3Text.cfg) | CSGO cfg | 12 | 0 | 4 | 16 |
| [Ticker/CSRMTicker.cfg](/Ticker/CSRMTicker.cfg) | CSGO cfg | 53 | 0 | 24 | 77 |
| [Ticker/CSRMTicker1.cfg](/Ticker/CSRMTicker1.cfg) | CSGO cfg | 120,001 | 0 | 1 | 120,002 |
| [Ticker/CSRMTicker10.cfg](/Ticker/CSRMTicker10.cfg) | CSGO cfg | 120,010 | 0 | 1 | 120,011 |
| [Ticker/CSRMTicker11.cfg](/Ticker/CSRMTicker11.cfg) | CSGO cfg | 120,011 | 0 | 1 | 120,012 |
| [Ticker/CSRMTicker12.cfg](/Ticker/CSRMTicker12.cfg) | CSGO cfg | 120,012 | 0 | 1 | 120,013 |
| [Ticker/CSRMTicker13.cfg](/Ticker/CSRMTicker13.cfg) | CSGO cfg | 120,013 | 0 | 1 | 120,014 |
| [Ticker/CSRMTicker14.cfg](/Ticker/CSRMTicker14.cfg) | CSGO cfg | 120,014 | 0 | 1 | 120,015 |
| [Ticker/CSRMTicker15.cfg](/Ticker/CSRMTicker15.cfg) | CSGO cfg | 120,015 | 0 | 1 | 120,016 |
| [Ticker/CSRMTicker16.cfg](/Ticker/CSRMTicker16.cfg) | CSGO cfg | 120,016 | 0 | 1 | 120,017 |
| [Ticker/CSRMTicker17.cfg](/Ticker/CSRMTicker17.cfg) | CSGO cfg | 120,017 | 0 | 1 | 120,018 |
| [Ticker/CSRMTicker18.cfg](/Ticker/CSRMTicker18.cfg) | CSGO cfg | 120,018 | 0 | 1 | 120,019 |
| [Ticker/CSRMTicker19.cfg](/Ticker/CSRMTicker19.cfg) | CSGO cfg | 120,019 | 0 | 1 | 120,020 |
| [Ticker/CSRMTicker2.cfg](/Ticker/CSRMTicker2.cfg) | CSGO cfg | 120,002 | 0 | 1 | 120,003 |
| [Ticker/CSRMTicker20.cfg](/Ticker/CSRMTicker20.cfg) | CSGO cfg | 120,021 | 0 | 0 | 120,021 |
| [Ticker/CSRMTicker3.cfg](/Ticker/CSRMTicker3.cfg) | CSGO cfg | 120,003 | 0 | 1 | 120,004 |
| [Ticker/CSRMTicker4.cfg](/Ticker/CSRMTicker4.cfg) | CSGO cfg | 120,004 | 0 | 1 | 120,005 |
| [Ticker/CSRMTicker5.cfg](/Ticker/CSRMTicker5.cfg) | CSGO cfg | 120,005 | 0 | 1 | 120,006 |
| [Ticker/CSRMTicker6.cfg](/Ticker/CSRMTicker6.cfg) | CSGO cfg | 120,006 | 0 | 1 | 120,007 |
| [Ticker/CSRMTicker7.cfg](/Ticker/CSRMTicker7.cfg) | CSGO cfg | 120,007 | 0 | 1 | 120,008 |
| [Ticker/CSRMTicker8.cfg](/Ticker/CSRMTicker8.cfg) | CSGO cfg | 120,008 | 0 | 1 | 120,009 |
| [Ticker/CSRMTicker9.cfg](/Ticker/CSRMTicker9.cfg) | CSGO cfg | 120,009 | 0 | 1 | 120,010 |
| [Ticker/CSRMTickerGen.cpp](/Ticker/CSRMTickerGen.cpp) | C++ | 42 | 2 | 1 | 45 |
| [install/AutoAddUtility.py](/install/AutoAddUtility.py) | Python | 191 | 14 | 35 | 240 |
| [install/CSRM_install.ps1](/install/CSRM_install.ps1) | PowerShell | 769 | 87 | 127 | 983 |
| [install/CSRM_install_only_Resource.ps1](/install/CSRM_install_only_Resource.ps1) | PowerShell | 32 | 3 | 10 | 45 |
| [install/CSRM_install_withoutwm.ps1](/install/CSRM_install_withoutwm.ps1) | PowerShell | 757 | 87 | 124 | 968 |
| [install/CSRM_install_withoutwm_only_Resource.ps1](/install/CSRM_install_withoutwm_only_Resource.ps1) | PowerShell | 45 | 6 | 11 | 62 |
| [install/CustomGrenadeRegSource.cpp](/install/CustomGrenadeRegSource.cpp) | C++ | 73 | 1 | 3 | 77 |
| [install/Key.ps1](/install/Key.ps1) | PowerShell | 224 | 2 | 5 | 231 |
| [install/setfps.ps1](/install/setfps.ps1) | PowerShell | 51 | 7 | 13 | 71 |
| [一键CFG安装(或重新设置CFG).bat](/%E4%B8%80%E9%94%AECFG%E5%AE%89%E8%A3%85(%E6%88%96%E9%87%8D%E6%96%B0%E8%AE%BE%E7%BD%AECFG).bat) | Batch | 72 | 6 | 13 | 91 |
| [一键应用自定义道具.bat](/%E4%B8%80%E9%94%AE%E5%BA%94%E7%94%A8%E8%87%AA%E5%AE%9A%E4%B9%89%E9%81%93%E5%85%B7.bat) | Batch | 2 | 0 | 0 | 2 |
| [一键添加自定义道具(半成品).bat](/%E4%B8%80%E9%94%AE%E6%B7%BB%E5%8A%A0%E8%87%AA%E5%AE%9A%E4%B9%89%E9%81%93%E5%85%B7(%E5%8D%8A%E6%88%90%E5%93%81).bat) | Batch | 2 | 0 | 0 | 2 |
| [如果发现轮盘没字了点我.bat](/%E5%A6%82%E6%9E%9C%E5%8F%91%E7%8E%B0%E8%BD%AE%E7%9B%98%E6%B2%A1%E5%AD%97%E4%BA%86%E7%82%B9%E6%88%91.bat) | Batch | 39 | 4 | 8 | 51 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)